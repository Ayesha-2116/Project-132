
#import <Foundation/Foundation.h>




__attribute__((visibility("default"))) @interface AgoraRtePlayerCustomSourceProvider : NSObject

- (instancetype _Nonnull)init;

@end
