/**
 *
 * Agora Real Time Engagement
 * Copyright (c) 2024 Agora IO. All rights reserved.
 *
 */


#import <Foundation/Foundation.h>

__attribute__((visibility("default"))) @interface AgoraRteObserver : NSObject

- (instancetype _Nonnull)init;

@end
